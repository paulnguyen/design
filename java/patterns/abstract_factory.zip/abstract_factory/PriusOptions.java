package abstract_factory;

public class PriusOptions extends PriusPart {

}
