package abstract_factory;

public abstract class TeslaPart extends FactoryPart {

}
