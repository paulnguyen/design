package abstract_factory;

public abstract class FactoryPart {

}
