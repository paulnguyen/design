package abstract_factory;

public class VolvoOptions extends VolvoPart {

}
