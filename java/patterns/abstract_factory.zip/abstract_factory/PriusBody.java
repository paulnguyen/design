package abstract_factory;

public class PriusBody extends PriusPart {

}
