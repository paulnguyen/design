package abstract_factory;

public class ElectricEngine extends TeslaPart {

}
